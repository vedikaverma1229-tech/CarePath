import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { aiService } from '../services/aiService';
import { ChatMessageItem, ConversationState, StructuredGuidanceResult } from '../types';
import { ChatMessage } from '../components/ChatMessage';
import { VoiceInput } from '../components/VoiceInput';
import { VoiceAssistantCard } from '../components/VoiceAssistantCard';
import { GuidanceResult } from '../components/GuidanceResult';
import { EmergencyCard } from '../components/EmergencyCard';
import { LiveVoiceModal } from '../components/LiveVoiceModal';
import {
  Send,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  HeartPulse,
  Info,
  CheckCircle,
  AlertTriangle,
  Stethoscope,
  Calendar,
  Radio,
  ArrowRight,
} from 'lucide-react';

export const Guidance: React.FC = () => {
  const { t, language } = useLanguage();
  const [messages, setMessages] = useState<ChatMessageItem[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [sessionId, setSessionId] = useState('');
  const [conversationState, setConversationState] = useState<ConversationState>('IDLE');
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [guidanceResult, setGuidanceResult] = useState<StructuredGuidanceResult | null>(null);
  const [emergencyResult, setEmergencyResult] = useState<StructuredGuidanceResult | null>(null);
  const [reportedObservations, setReportedObservations] = useState<string[]>([]);
  const [isLiveVoiceOpen, setIsLiveVoiceOpen] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, conversationState]);

  // Initialize conversation
  const initializeChat = async () => {
    setConversationState('PROCESSING');
    setStatusMessage('Connecting to CarePath AI Health Assistant...');
    setGuidanceResult(null);
    setEmergencyResult(null);
    setReportedObservations([]);

    try {
      const response = await aiService.startConversation(language);
      setSessionId(response.sessionId);
      setMessages([
        {
          id: 'msg-init',
          sender: 'assistant',
          text:
            language === 'hi'
              ? 'नमस्ते! मैं CarePath AI Health Assistant हूँ। आज आपकी स्वास्थ्य सम्बन्धी क्या समस्या है? बोलें या नीचे दिए गए विकल्पों में से चुनें।'
              : language === 'mr'
              ? 'नमस्कार! मी CarePath AI Health Assistant आहे. आज तुम्हाला आरोग्याची काय अडचण आहे? कृपया सांगा किंवा खालील पर्याय निवडा.'
              : 'Namaste! I am CarePath AI Health Assistant. Tell me what health concern is bothering you today, or choose a symptom below.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          suggestions:
            language === 'hi'
              ? ['मुझे 3-4 दिन से बुखार है', 'सीने में दर्द या भारीपन', 'खांसी और सांस लेने में तकलीफ', 'पेट दर्द']
              : language === 'mr'
              ? ['मला ३-४ दिवसांपासून ताप आहे', 'छातीत दुखणे', 'खोकला आणि श्वास घेण्यास त्रास', 'पोटदुखी']
              : ['I have fever from 3-4 days', 'Chest pain or heavy breathing', 'Cough & throat irritation', 'Stomach ache'],
        },
      ]);
      setConversationState('AI_ASKING');
    } catch (err) {
      console.error(err);
      setConversationState('ERROR');
      setStatusMessage('Something went wrong connecting to the session. Please try again.');
    }
  };

  useEffect(() => {
    initializeChat();
  }, [language]);

  // Handle sending a message
  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputValue).trim();
    if (!text || conversationState === 'PROCESSING') return;

    // Add user message
    const userMsg: ChatMessageItem = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue('');
    setReportedObservations((prev) => [...prev, text]);

    // Update state to processing
    setConversationState('PROCESSING');
    setStatusMessage('CarePath AI is understanding your response...');

    try {
      const response = await aiService.sendMessage(text, sessionId, language);

      if (response.isEmergency) {
        setConversationState('EMERGENCY');
        setEmergencyResult(response.guidanceResult || null);
        const emergencyMsg: ChatMessageItem = {
          id: `ai-emg-${Date.now()}`,
          sender: 'assistant',
          text:
            language === 'hi'
              ? '🚨 आपातकालीन चेतावनी: आपके लक्षण गंभीर लग रहे हैं। कृपया तुरंत 112 पर कॉल करें या नजदीकी आपातकालीन अस्पताल जाएं।'
              : '🚨 CRITICAL MEDICAL ALERT: Your symptoms indicate an urgent medical situation. Please dial 112 or visit the nearest emergency trauma facility immediately.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isEmergencyAlert: true,
        };
        setMessages((prev) => [...prev, emergencyMsg]);
        return;
      }

      if (response.guidanceResult) {
        setGuidanceResult(response.guidanceResult);
        setConversationState('GUIDANCE_READY');
        const finalMsg: ChatMessageItem = {
          id: `ai-done-${Date.now()}`,
          sender: 'assistant',
          text:
            language === 'hi'
              ? 'आपके लक्षणों के आधार पर हमने अगला सुरक्षित कदम तैयार किया है। कृपया नीचे दिए गए परिणाम और डॉक्टरों की सूची देखें।'
              : 'Based on the details provided, here is your care guidance and recommended next step.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          guidanceResult: response.guidanceResult,
        };
        setMessages((prev) => [...prev, finalMsg]);
      } else if (response.nextQuestion) {
        setConversationState('AI_ASKING');
        const nextMsg: ChatMessageItem = {
          id: `ai-${Date.now()}`,
          sender: 'assistant',
          text: response.nextQuestion,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          suggestions: response.suggestions,
        };
        setMessages((prev) => [...prev, nextMsg]);
      }
    } catch (err) {
      console.error(err);
      setConversationState('ERROR');
      setStatusMessage('Unable to reach AI assistant. Switching to clinical guidance.');
    }
  };

  // Called when voice recognition finishes speech-to-text
  const handleVoiceTranscript = (recognizedText: string, autoSend: boolean = false) => {
    setInputValue(recognizedText);
    if (autoSend) {
      handleSendMessage(recognizedText);
    } else {
      chatInputRef.current?.focus();
    }
  };

  // Emergency sample trigger for clinical testing
  const triggerEmergencyTest = () => {
    handleSendMessage('I have sudden severe chest pain with left arm radiation and breathless sweating!');
  };

  return (
    <div className="min-h-screen py-6 sm:py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto" style={{ backgroundColor: '#FFF9F9' }}>
      
      {/* Header Banner - Central Feature of CAREPATH */}
      <div
        className="rounded-3xl p-6 sm:p-8 mb-8 border shadow-xs"
        style={{ backgroundColor: '#FFFFFF', borderColor: '#F4B6B6' }}
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border"
              style={{
                backgroundColor: '#FFF1F1',
                color: '#D94A4A',
                borderColor: '#F4B6B6',
              }}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>CarePath AI Health Assistant</span>
            </div>
            
            <h1
              className="font-['Outfit'] text-2xl sm:text-4xl font-extrabold tracking-tight"
              style={{ color: '#252525' }}
            >
              CarePath AI Health Assistant
            </h1>
            
            <p
              className="text-sm sm:text-base font-medium max-w-2xl leading-relaxed"
              style={{ color: '#A83232' }}
            >
              “Tell me about your health concern and I'll help you understand the next step.”
            </p>
          </div>

          {/* Quick Action Controls */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Live Real-Time Voice Consultation */}
            <button
              onClick={() => setIsLiveVoiceOpen(true)}
              className="px-4 py-2.5 rounded-xl font-bold text-xs text-white shadow-xs transition-all hover:bg-[#A83232] flex items-center gap-2"
              style={{ backgroundColor: '#D94A4A' }}
            >
              <Radio className="w-3.5 h-3.5 animate-pulse text-white" />
              <span>Real-Time Voice Assistant</span>
            </button>

            {/* Reset Conversation */}
            <button
              onClick={initializeChat}
              className="px-3 py-2.5 rounded-xl text-xs font-bold border transition-colors flex items-center gap-1.5 hover:bg-[#FFF1F1]"
              style={{
                backgroundColor: '#FFFFFF',
                color: '#252525',
                borderColor: '#F4B6B6',
              }}
              title="Reset Conversation"
            >
              <RotateCcw className="w-3.5 h-3.5" style={{ color: '#D94A4A' }} />
              <span>Restart Chat</span>
            </button>
          </div>
        </div>

        {/* Safety Disclaimer Banner */}
        <div
          className="mt-4 p-3.5 rounded-2xl flex items-center gap-2.5 text-xs border"
          style={{ backgroundColor: '#FFF1F1', borderColor: '#F4B6B6', color: '#252525' }}
        >
          <ShieldCheck className="w-4 h-4 shrink-0" style={{ color: '#2E9B68' }} />
          <span>
            <strong>Safety Notice:</strong> CarePath provides healthcare guidance and navigation support. It does not replace professional medical diagnosis or treatment. In life-threatening emergencies, dial 112 immediately.
          </span>
        </div>
      </div>

      {/* Prominent Voice Assistance Card */}
      <div className="mb-8">
        <VoiceAssistantCard
          onSpeechRecognized={(text) => handleVoiceTranscript(text, false)}
          onSendDirectly={(text) => handleSendMessage(text)}
          isProcessing={conversationState === 'PROCESSING'}
        />
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Conversational AI Interface */}
        <div className="lg:col-span-8 flex flex-col space-y-4">
          
          {/* Chat Window Card */}
          <div
            className="rounded-3xl border shadow-xs overflow-hidden flex flex-col h-[620px]"
            style={{ backgroundColor: '#FFFFFF', borderColor: '#F4B6B6' }}
          >
            {/* Chat Header */}
            <div
              className="px-5 py-3.5 border-b flex items-center justify-between"
              style={{ backgroundColor: '#FFF9F9', borderColor: '#F4B6B6' }}
            >
              <div className="flex items-center gap-2.5">
                <div
                  className="w-8 h-8 rounded-xl flex items-center justify-center text-white"
                  style={{ backgroundColor: '#D94A4A' }}
                >
                  <HeartPulse className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-['Outfit'] font-bold text-sm block" style={{ color: '#252525' }}>
                    CarePath Consultation Chat
                  </span>
                  <span className="text-[11px] text-slate-500">
                    Session: <span className="font-mono">{sessionId.slice(0, 8)}...</span>
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: '#2E9B68' }} />
                <span className="text-xs font-semibold" style={{ color: '#2E9B68' }}>Ready & Listening</span>
              </div>
            </div>

            {/* Messages Body */}
            <div className="flex-1 p-5 overflow-y-auto space-y-4" style={{ backgroundColor: '#FFFFFF' }}>
              {messages.map((msg) => (
                <ChatMessage
                  key={msg.id}
                  message={msg}
                  onSelectSuggestion={(sug) => handleSendMessage(sug)}
                />
              ))}

              {/* Typing / Processing Indicator */}
              {conversationState === 'PROCESSING' && (
                <div
                  className="flex items-center gap-2 text-xs p-3 rounded-2xl max-w-sm border"
                  style={{ backgroundColor: '#FFF1F1', borderColor: '#F4B6B6', color: '#252525' }}
                >
                  <span className="w-2 h-2 rounded-full animate-bounce" style={{ backgroundColor: '#D94A4A' }} />
                  <span className="w-2 h-2 rounded-full animate-bounce [animation-delay:0.2s]" style={{ backgroundColor: '#D94A4A' }} />
                  <span className="w-2 h-2 rounded-full animate-bounce [animation-delay:0.4s]" style={{ backgroundColor: '#D94A4A' }} />
                  <span className="ml-1 font-medium">{statusMessage || 'Understanding your symptoms...'}</span>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Quick Emergency Escalation Option */}
            <div
              className="px-5 py-2 border-t flex items-center justify-between text-xs"
              style={{ backgroundColor: '#FFF9F9', borderColor: '#F4B6B6' }}
            >
              <span className="text-slate-500">Sudden acute pain, bleeding, or breathless?</span>
              <button
                type="button"
                onClick={triggerEmergencyTest}
                className="font-bold underline text-xs cursor-pointer hover:opacity-80"
                style={{ color: '#9E2020' }}
              >
                Emergency Assistance (112)
              </button>
            </div>

            {/* Input Bar */}
            <div
              className="p-4 border-t flex items-center gap-2"
              style={{ backgroundColor: '#FFFFFF', borderColor: '#F4B6B6' }}
            >
              <input
                ref={chatInputRef}
                type="text"
                placeholder={
                  language === 'hi'
                    ? 'अपनी समस्या यहाँ लिखें या माइक पर बोलें...'
                    : language === 'mr'
                    ? 'तुमची अडचण येथे लिहा किंवा बोला...'
                    : 'Type symptoms or click mic to speak...'
                }
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSendMessage();
                }}
                disabled={conversationState === 'PROCESSING'}
                className="flex-1 text-sm px-4 py-3 rounded-xl border focus:outline-none focus:ring-2 focus:ring-[#F4B6B6] transition-all bg-white"
                style={{
                  borderColor: '#F4B6B6',
                  color: '#252525',
                }}
              />

              {/* Voice recognition microphone input button */}
              <VoiceInput
                onTranscript={(transcript) => handleVoiceTranscript(transcript, false)}
                language={language}
                disabled={conversationState === 'PROCESSING'}
                onFocusTextInput={() => chatInputRef.current?.focus()}
              />

              {/* Send Button */}
              <button
                type="button"
                onClick={() => handleSendMessage()}
                disabled={!inputValue.trim() || conversationState === 'PROCESSING'}
                className="p-3 rounded-xl text-white shadow-xs transition-transform active:scale-95 disabled:opacity-40 hover:bg-[#A83232]"
                style={{ backgroundColor: '#D94A4A' }}
                aria-label="Send message"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Structured Guidance Result (When Complete) */}
          {guidanceResult && (
            <div className="mt-4">
              <GuidanceResult result={guidanceResult} />
            </div>
          )}

          {/* Emergency Card Display if triggered */}
          {emergencyResult && (
            <div className="mt-4">
              <EmergencyCard reason={emergencyResult.reason} />
            </div>
          )}
        </div>

        {/* Right Column: "Current Understanding" Panel on Desktop */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Understanding Status Card */}
          <div
            className="rounded-3xl border p-5 sm:p-6 shadow-xs"
            style={{ backgroundColor: '#FFFFFF', borderColor: '#F4B6B6' }}
          >
            <div className="flex items-center gap-2 mb-4">
              <Info className="w-4 h-4" style={{ color: '#D94A4A' }} />
              <h2 className="font-['Outfit'] font-bold text-base" style={{ color: '#252525' }}>
                Current Understanding
              </h2>
            </div>

            {/* Care Level Gauge */}
            <div
              className="mb-4 p-3.5 rounded-2xl border"
              style={{ backgroundColor: '#FFF9F9', borderColor: '#F4B6B6' }}
            >
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Triage Progression
              </span>
              <div className="flex items-center justify-between text-xs font-semibold">
                <span style={{ color: guidanceResult ? '#2E9B68' : '#252525' }}>
                  {guidanceResult ? 'Guidance Ready' : conversationState === 'PROCESSING' ? 'Understanding...' : 'Gathering Symptoms'}
                </span>
                <span className="text-[11px] text-slate-500 font-mono">
                  {reportedObservations.length} logged
                </span>
              </div>
              <div className="w-full bg-[#FFF1F1] h-2 rounded-full mt-2 overflow-hidden border border-[#F4B6B6]">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: guidanceResult ? '100%' : `${Math.min(90, reportedObservations.length * 30 + 20)}%`,
                    backgroundColor: guidanceResult ? '#2E9B68' : '#D94A4A',
                  }}
                />
              </div>
            </div>

            {/* Collected Observations */}
            <div className="space-y-2 mb-4">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Reported Symptoms
              </span>
              {reportedObservations.length === 0 ? (
                <p className="text-xs text-slate-400 italic">
                  No symptoms logged yet. Speak or type to begin.
                </p>
              ) : (
                <div className="flex flex-wrap gap-1.5">
                  {reportedObservations.map((obs, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-lg text-xs font-medium border"
                      style={{
                        backgroundColor: '#FFF1F1',
                        color: '#D94A4A',
                        borderColor: '#F4B6B6',
                      }}
                    >
                      {obs.slice(0, 32)}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Suggested Doctor Specialty based on symptoms */}
            <div className="pt-3 border-t border-slate-100">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                Recommended Department
              </span>
              <div className="flex items-center gap-2 text-xs font-bold" style={{ color: '#252525' }}>
                <Stethoscope className="w-4 h-4" style={{ color: '#D94A4A' }} />
                <span>
                  {guidanceResult?.recommendedDoctorType || 'General Medicine (Physician)'}
                </span>
              </div>
            </div>

            {/* Direct Connect Action */}
            <div className="mt-5 space-y-2">
              <Link
                to="/doctors"
                className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-white shadow-xs flex items-center justify-center gap-1.5 transition-colors hover:bg-[#A83232]"
                style={{ backgroundColor: '#D94A4A' }}
              >
                <Stethoscope className="w-3.5 h-3.5" />
                <span>Find Nearby Doctors</span>
              </Link>

              <Link
                to="/appointments"
                className="w-full py-2.5 px-4 rounded-xl text-xs font-bold border flex items-center justify-center gap-1.5 transition-colors hover:bg-[#FFF1F1]"
                style={{
                  backgroundColor: '#FFFFFF',
                  color: '#252525',
                  borderColor: '#F4B6B6',
                }}
              >
                <Calendar className="w-3.5 h-3.5" style={{ color: '#D94A4A' }} />
                <span>Schedule Appointment</span>
              </Link>
            </div>
          </div>

          {/* Clinical Guidance Philosophy */}
          <div
            className="rounded-3xl border p-5 shadow-xs"
            style={{ backgroundColor: '#FFFFFF', borderColor: '#F4B6B6' }}
          >
            <h3 className="font-['Outfit'] font-bold text-sm mb-3" style={{ color: '#252525' }}>
              The 4-Step Patient Journey
            </h3>
            <div className="space-y-3 text-xs">
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white shrink-0" style={{ backgroundColor: '#D94A4A' }}>1</span>
                <div>
                  <strong style={{ color: '#252525' }}>Talk:</strong> Explain what you are feeling in natural Hindi, Marathi, or English.
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white shrink-0" style={{ backgroundColor: '#D94A4A' }}>2</span>
                <div>
                  <strong style={{ color: '#252525' }}>Understand:</strong> CarePath clarifies duration, temperature, and severity.
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white shrink-0" style={{ backgroundColor: '#D94A4A' }}>3</span>
                <div>
                  <strong style={{ color: '#252525' }}>Guide:</strong> Receive clear next-step guidance for Home Care, Clinic, or Hospital.
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white shrink-0" style={{ backgroundColor: '#D94A4A' }}>4</span>
                <div>
                  <strong style={{ color: '#252525' }}>Connect:</strong> Book appointments with vetted doctors or locate hospital casualty units.
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* Live Voice Real-Time Modal */}
      <LiveVoiceModal
        isOpen={isLiveVoiceOpen}
        onClose={() => setIsLiveVoiceOpen(false)}
        onGuidanceGenerated={(res) => {
          setGuidanceResult(res);
          setIsLiveVoiceOpen(false);
        }}
      />

    </div>
  );
};
