import React, { useState, useEffect } from 'react';
import { Download, Copy, Check, FileCode, Folder, ChevronRight, Terminal, RefreshCw, Eye } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface FileItem {
  path: string;
  name: string;
  category: string;
}

export const ProjectCodeViewer: React.FC = () => {
  const { t } = useLanguage();
  const [files, setFiles] = useState<string[]>([]);
  const [selectedFile, setSelectedFile] = useState<string>('server.ts');
  const [fileContent, setFileContent] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Fetch file list
  useEffect(() => {
    fetch('/api/files')
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.files) {
          setFiles(data.files);
          if (data.files.includes('server.ts')) {
            setSelectedFile('server.ts');
          } else if (data.files.length > 0) {
            setSelectedFile(data.files[0]);
          }
        }
      })
      .catch((err) => console.error('Failed to load file list:', err));
  }, []);

  // Fetch file content whenever selectedFile changes
  useEffect(() => {
    if (!selectedFile) return;
    setLoading(true);
    fetch(`/api/file-content?path=${encodeURIComponent(selectedFile)}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setFileContent(data.content);
        } else {
          setFileContent('// Error loading file: ' + (data.error || 'Unknown error'));
        }
      })
      .catch((err) => {
        setFileContent('// Network error loading file: ' + err.message);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [selectedFile]);

  const handleCopy = () => {
    navigator.clipboard.writeText(fileContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadSingle = () => {
    const blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = selectedFile.split('/').pop() || 'file.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredFiles = files.filter((f) =>
    f.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getCategory = (path: string) => {
    if (path.startsWith('backend/data/')) return '📊 Mock Data';
    if (path.startsWith('backend/services/')) return '⚙️ Backend Services';
    if (path.startsWith('backend/controllers/')) return '🎛️ Controllers';
    if (path.startsWith('backend/routes/')) return '🛣️ REST Routes';
    if (path.startsWith('src/components/')) return '🧩 Components';
    if (path.startsWith('src/pages/')) return '📄 Pages';
    if (path.startsWith('src/services/')) return '🔌 Client Services';
    if (path.startsWith('src/context/')) return '🌐 State / Context';
    if (path.startsWith('src/types/')) return '📝 Types';
    return '🛠️ Core Config';
  };

  const categories = Array.from(new Set(filteredFiles.map(getCategory)));

  return (
    <div className="min-h-screen py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto" style={{ backgroundColor: '#FFF9F9' }}>
      
      {/* Header Banner */}
      <div
        className="rounded-2xl p-6 sm:p-8 mb-8 border shadow-xs"
        style={{ backgroundColor: '#FFFFFF', borderColor: '#F4B6B6' }}
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold mb-3 border"
              style={{ backgroundColor: '#FFF1F1', color: '#D94A4A', borderColor: '#F4B6B6' }}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>Full Source Code Explorer</span>
            </div>
            <h1 className="font-['Outfit'] text-2xl sm:text-3xl font-extrabold tracking-tight" style={{ color: '#252525' }}>
              Complete Source Code Repository
            </h1>
            <p className="text-sm mt-1 text-slate-600 max-w-2xl">
              Inspect and copy every file from the CAREPATH application, or download the full bundle to run locally in VS Code with a single command.
            </p>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-wrap items-center gap-3">
            <a
              href="/carepath-vscode.zip"
              download="carepath-vscode.zip"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl font-bold text-sm text-white shadow-md transition-all hover:scale-102"
              style={{ backgroundColor: '#D94A4A' }}
            >
              <Download className="w-4 h-4" />
              <span>Download Full Project (.ZIP)</span>
            </a>
          </div>
        </div>

        {/* Quick run command info */}
        <div
          className="mt-6 p-4 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs border"
          style={{ backgroundColor: '#FFF1F1', borderColor: '#F4B6B6' }}
        >
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 shrink-0" style={{ color: '#D94A4A' }} />
            <span className="font-semibold text-slate-800">
              Run in VS Code terminal:
            </span>
            <code className="bg-white px-2 py-1 rounded border border-[#F4B6B6] font-mono text-[#D94A4A]">
              npm install && npm run dev
            </code>
          </div>
          <span className="text-slate-500 font-medium">
            Starts Express + React on <strong className="text-slate-700">http://localhost:3000</strong>
          </span>
        </div>
      </div>

      {/* Main Code Explorer Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Sidebar: File Tree */}
        <div
          className="lg:col-span-4 rounded-2xl border p-4 shadow-xs max-h-[750px] flex flex-col"
          style={{ backgroundColor: '#FFFFFF', borderColor: '#F4B6B6' }}
        >
          <div className="mb-3">
            <input
              type="text"
              placeholder="Search files (e.g. doctor, heart, server)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs px-3 py-2 rounded-xl border focus:outline-none"
              style={{
                borderColor: '#F4B6B6',
                backgroundColor: '#FFF9F9',
                color: '#252525',
              }}
            />
          </div>

          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center justify-between">
            <span>Project Files ({filteredFiles.length})</span>
            <span className="text-[10px] text-slate-400 font-normal">Click to view</span>
          </div>

          <div className="overflow-y-auto space-y-4 pr-1 flex-1">
            {categories.map((cat) => {
              const catFiles = filteredFiles.filter((f) => getCategory(f) === cat);
              return (
                <div key={cat} className="space-y-1">
                  <div className="text-[11px] font-bold text-slate-700 px-2 py-1 bg-slate-50 rounded">
                    {cat}
                  </div>
                  <div className="space-y-0.5 pl-1">
                    {catFiles.map((file) => {
                      const isSelected = selectedFile === file;
                      const fileName = file.split('/').pop() || file;
                      return (
                        <button
                          key={file}
                          onClick={() => setSelectedFile(file)}
                          className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-mono transition-colors flex items-center justify-between ${
                            isSelected
                              ? 'text-white font-bold shadow-2xs'
                              : 'text-slate-700 hover:bg-[#FFF1F1] hover:text-[#D94A4A]'
                          }`}
                          style={{
                            backgroundColor: isSelected ? '#D94A4A' : 'transparent',
                          }}
                        >
                          <span className="truncate">{fileName}</span>
                          <span className="text-[10px] opacity-70 ml-2 shrink-0 truncate max-w-[90px]">
                            {file.split('/').slice(0, -1).join('/') || '/'}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Area: Code View */}
        <div
          className="lg:col-span-8 rounded-2xl border shadow-xs overflow-hidden flex flex-col"
          style={{ backgroundColor: '#FFFFFF', borderColor: '#F4B6B6' }}
        >
          {/* File Toolbar */}
          <div
            className="px-4 py-3 border-b flex flex-wrap items-center justify-between gap-3"
            style={{ backgroundColor: '#FFF9F9', borderColor: '#F4B6B6' }}
          >
            <div className="flex items-center gap-2">
              <FileCode className="w-4 h-4" style={{ color: '#D94A4A' }} />
              <span className="font-mono text-xs sm:text-sm font-bold" style={{ color: '#252525' }}>
                {selectedFile}
              </span>
              <span className="text-xs text-slate-400">
                ({fileContent.split('\n').length} lines)
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all border shadow-2xs"
                style={{
                  backgroundColor: copied ? '#2E9B68' : '#FFFFFF',
                  color: copied ? '#FFFFFF' : '#252525',
                  borderColor: copied ? '#2E9B68' : '#F4B6B6',
                }}
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied Code!' : 'Copy Code'}</span>
              </button>

              <button
                onClick={handleDownloadSingle}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all border shadow-2xs bg-white text-slate-700 hover:bg-[#FFF1F1]"
                style={{ borderColor: '#F4B6B6' }}
              >
                <Download className="w-3.5 h-3.5" />
                <span>Save File</span>
              </button>
            </div>
          </div>

          {/* Code Container */}
          <div className="relative max-h-[680px] overflow-auto bg-[#1e1e1e] p-4 font-mono text-xs sm:text-sm leading-relaxed text-slate-200">
            {loading ? (
              <div className="flex items-center justify-center py-20 text-slate-400 gap-2">
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Loading file content...</span>
              </div>
            ) : (
              <pre className="whitespace-pre overflow-x-auto selection:bg-[#D94A4A] selection:text-white">
                <code>{fileContent}</code>
              </pre>
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
