import { StructuredGuidanceResult } from '../types';

/**
 * =========================================================================
 * AI MODULE PLACEHOLDER
 * TO BE IMPLEMENTED BY PROJECT OWNER
 * =========================================================================
 * 
 * IMPORTANT ARCHITECTURAL BOUNDARY:
 * This frontend service connects to the AI reasoning module.
 * In production, the Project Owner will plug their proprietary medical
 * reasoning engine (custom fine-tuned models, clinical rule graphs, or triage microservices).
 * 
 * NO LLM APIs (OpenAI, Gemini, Claude) or medical diagnosis logic are executed here.
 * The system adheres to the structured AI response contract.
 */

export interface AIServiceResponse {
  sessionId: string;
  nextQuestion?: string;
  suggestions?: string[];
  guidanceResult?: StructuredGuidanceResult;
  isEmergency?: boolean;
}

// Scripted conversational questions for offline client-side triage pipeline
const DEMO_QUESTIONS = [
  {
    step: 1,
    questionEn: 'How long have you had the fever? (Fever kab se hai?)',
    questionHi: 'बुखार कब से है? कितने दिनों से तापमान बढ़ा हुआ है?',
    questionMr: 'ताप कधीपासून आहे? किती दिवसांपासून कणकण वाटते आहे?',
    suggestions: ['2 din se (Since 2 days)', 'Aaj subah se (Today)', 'More than 4 days'],
  },
  {
    step: 2,
    questionEn: 'What is the recorded body temperature? (Temperature kitna hai?)',
    questionHi: 'तापमान कितना है? क्या थर्मामीटर से नापा है?',
    questionMr: 'अंदाजे किती तापमान मोजले आहे?',
    suggestions: ['101°F', '100°F (Mild)', '102°F or higher', 'Not measured'],
  },
  {
    step: 3,
    questionEn: 'Are there severe danger symptoms like chest pain, heavy breathing difficulty, or fainting? (Kya chest pain ya breathing difficulty hai?)',
    questionHi: 'क्या सीने में तेज दर्द, सांस लेने में तकलीफ या बेहोशी है?',
    questionMr: 'छातीत दुखणे किंवा श्वास घेण्यास खूप त्रास होत आहे का?',
    suggestions: ['No', 'Yes, severe breathing difficulty', 'Mild body weakness only'],
  },
];

const STANDARD_DEMO_RESULT: StructuredGuidanceResult = {
  conversationId: 'demo-carepath-001',
  status: 'guidance_complete',
  careLevel: 'CLINIC',
  reason: 'Based on the 2-day fever of 101°F with mild weakness and no chest pain or breathing distress, an in-person consultation with a local General Physician is advised for clinical checkup and routine screening.',
  emergency: false,
  symptoms: ['Fever (2 days)', '101°F', 'Mild weakness', 'No chest pain'],
  recommendedSpecialty: 'General Medicine',
  location: 'Nagpur',
  budget: 500,
  language: 'Hindi',
};

const EMERGENCY_DEMO_RESULT: StructuredGuidanceResult = {
  conversationId: 'demo-carepath-urgent-999',
  status: 'emergency_escalation',
  careLevel: 'URGENT_HOSPITAL',
  reason: 'Reported chest pain and respiratory distress are potential acute red flags. Immediate hospital evaluation is urgently recommended.',
  emergency: true,
  symptoms: ['Chest pain', 'Severe breathing difficulty'],
  recommendedSpecialty: 'Cardiology',
  location: 'Nagpur',
  budget: 1000,
  language: 'Hindi',
};

class AIService {
  private currentStep = 0;
  private currentSessionId = 'demo-session-' + Date.now();
  private userAnswers: string[] = [];

  /**
   * Initializes or resets a conversation session.
   * // AI MODULE PLACEHOLDER
   * // TO BE IMPLEMENTED BY PROJECT OWNER
   */
  async startConversation(language = 'en'): Promise<AIServiceResponse> {
    this.currentStep = 0;
    this.userAnswers = [];
    this.currentSessionId = 'demo-session-' + Date.now();

    try {
      const res = await fetch('/api/ai/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ language }),
      });
      if (res.ok) {
        const data = await res.json();
        return {
          sessionId: data.sessionId,
          nextQuestion: data.session?.history[0]?.text,
        };
      }
    } catch {
      // Backend starting or client-only fallback
    }

    let initialQ = 'Namaste! Tell me what health concern is bothering you today.';
    if (language === 'hi') initialQ = 'नमस्ते! आज आपको क्या परेशानी हो रही है?';
    if (language === 'mr') initialQ = 'नमस्कार! आज आपल्याला काय त्रास होत आहे?';

    return {
      sessionId: this.currentSessionId,
      nextQuestion: initialQ,
      suggestions: [
        'Mujhe fever hai (I have fever)',
        'Severe chest pain & breathless',
        'Stomach ache and acidity',
        'Knee joint pain & swelling',
      ],
    };
  }

  /**
   * Submits a user message and returns the next structured turn.
   * // AI MODULE PLACEHOLDER
   * // TO BE IMPLEMENTED BY PROJECT OWNER
   */
  async sendMessage(message: string, sessionId?: string, language = 'en'): Promise<AIServiceResponse> {
    const sId = sessionId || this.currentSessionId;
    this.userAnswers.push(message);

    // Check emergency trigger
    const lower = message.toLowerCase();
    const isEmergency =
      lower.includes('chest pain') ||
      lower.includes('breathless') ||
      lower.includes('heart attack') ||
      lower.includes('behoshi') ||
      lower.includes('unconscious') ||
      lower.includes('saans lene me dikkat');

    // Attempt backend integration route
    try {
      const res = await fetch('/api/ai/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: sId, message }),
      });
      if (res.ok) {
        const json = await res.json();
        return {
          sessionId: sId,
          nextQuestion: json.data?.nextQuestion,
          suggestions: json.data?.suggestions,
          guidanceResult: json.data?.guidanceResult,
          isEmergency: json.data?.isEmergency,
        };
      }
    } catch {
      // Fallback to client-side offline guidance pipeline
    }

    // Client-side offline guidance fallback pipeline
    if (isEmergency) {
      return {
        sessionId: sId,
        isEmergency: true,
        guidanceResult: { ...EMERGENCY_DEMO_RESULT, conversationId: sId },
      };
    }

    if (this.currentStep < DEMO_QUESTIONS.length) {
      const q = DEMO_QUESTIONS[this.currentStep];
      this.currentStep++;

      let text = q.questionEn;
      if (language === 'hi') text = q.questionHi;
      if (language === 'mr') text = q.questionMr;

      return {
        sessionId: sId,
        nextQuestion: text,
        suggestions: q.suggestions,
        isEmergency: false,
      };
    } else {
      // Reached guidance result
      return {
        sessionId: sId,
        guidanceResult: { ...STANDARD_DEMO_RESULT, conversationId: sId },
        isEmergency: false,
      };
    }
  }

  /**
   * Submits a structured answer to a specific question ID.
   * // AI MODULE PLACEHOLDER
   * // TO BE IMPLEMENTED BY PROJECT OWNER
   */
  async submitAnswer(answer: string, _questionId?: string, sessionId?: string): Promise<AIServiceResponse> {
    return this.sendMessage(answer, sessionId);
  }

  /**
   * Retrieves the next question in the diagnostic sequence.
   * // AI MODULE PLACEHOLDER
   * // TO BE IMPLEMENTED BY PROJECT OWNER
   */
  async getNextQuestion(_sessionId?: string): Promise<string | null> {
    if (this.currentStep < DEMO_QUESTIONS.length) {
      return DEMO_QUESTIONS[this.currentStep].questionEn;
    }
    return null;
  }

  /**
   * Retrieves final guidance structured result.
   * // AI MODULE PLACEHOLDER
   * // TO BE IMPLEMENTED BY PROJECT OWNER
   */
  async getGuidanceResult(_sessionId?: string): Promise<StructuredGuidanceResult> {
    return STANDARD_DEMO_RESULT;
  }

  /**
   * Retrieves human-readable medical rationale for the recommendation.
   * // AI MODULE PLACEHOLDER
   * // TO BE IMPLEMENTED BY PROJECT OWNER
   */
  async getRecommendationReason(_sessionId?: string): Promise<string> {
    return STANDARD_DEMO_RESULT.reason;
  }

  /**
   * Checks if session indicates an emergency condition.
   * // AI MODULE PLACEHOLDER
   * // TO BE IMPLEMENTED BY PROJECT OWNER
   */
  async getEmergencyStatus(_sessionId?: string): Promise<boolean> {
    return false;
  }
}

export const aiService = new AIService();
export default aiService;
