import { GoogleGenAI } from '@google/genai';
import demoData from '../data/demoConversation.json';

export interface AISessionState {
  sessionId: string;
  language: string;
  step: number;
  history: Array<{
    sender: 'user' | 'assistant';
    text: string;
    timestamp: string;
  }>;
  collectedAnswers: Record<string, string>;
  isComplete: boolean;
  isEmergency?: boolean;
  guidanceResult?: any;
}

const sessions: Map<string, AISessionState> = new Map();

const apiKey = process.env.GEMINI_API_KEY || '';
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

const SYSTEM_INSTRUCTION = `You are CarePath AI Health Assistant, a healthcare guidance and triage navigation system for users in Tier-2/3 and rural communities.
Tagline: "From Referral to the Right Care".

CRITICAL MEDICAL SAFETY RULES:
1. Provide triage navigation and guidance ONLY. NEVER claim a definitive diagnosis or prescribe medication dosages.
2. Clearly reinforce: "CarePath provides health guidance and navigation support, not a medical diagnosis."
3. Ask 1-2 focused, compassionate follow-up questions when information is incomplete (e.g. temperature, duration, breathing difficulty, chest pain, medicines taken).
4. If red flag symptoms occur (chest pain, shortness of breath, loss of consciousness, severe bleeding, sudden weakness), immediately set emergency: true and careLevel: "URGENT_HOSPITAL".
5. Match user's language (English, Hindi, or Marathi).
6. When sufficient details are gathered (usually 2-3 turns), provide structured guidance.

Always respond in strictly valid JSON matching this schema:
{
  "message": "Assistant conversational reply in requested language",
  "isFollowUp": true/false,
  "quickSuggestions": ["Option 1", "Option 2", "Option 3"],
  "isEmergency": true/false,
  "guidanceResult": {
    "careLevel": "HOME_CARE" | "CLINIC" | "URGENT_HOSPITAL",
    "urgencyText": "string",
    "primaryConditionSummary": "string",
    "immediateActions": ["action 1", "action 2"],
    "recommendedDoctorType": "string",
    "warningSigns": ["sign 1", "sign 2"],
    "estimatedTimeframe": "string"
  } // or null if still asking follow-up questions
}`;

export class AIService {
  startConversation(language = 'en'): AISessionState {
    const sessionId = `session-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 7)}`;
    const initialDialogue = demoData.dialogue[0];

    let welcomeText = initialDialogue.aiQuestion;
    if (language === 'hi') welcomeText = initialDialogue.aiQuestionHi;
    if (language === 'mr') welcomeText = initialDialogue.aiQuestionMr;

    const session: AISessionState = {
      sessionId,
      language,
      step: 0,
      history: [
        {
          sender: 'assistant',
          text: welcomeText,
          timestamp: new Date().toISOString(),
        },
      ],
      collectedAnswers: {},
      isComplete: false,
    };

    sessions.set(sessionId, session);
    return session;
  }

  async sendMessage(
    sessionId: string,
    message: string,
    useDemoMode = false,
    language = 'en'
  ): Promise<{
    session: AISessionState;
    nextQuestion?: string;
    suggestions?: string[];
    guidanceResult?: any;
    isEmergency?: boolean;
    aiProvider?: 'gemini' | 'demo';
  }> {
    let session = sessions.get(sessionId);
    if (!session) {
      session = this.startConversation(language);
    }
    session.language = language || session.language;

    session.history.push({
      sender: 'user',
      text: message,
      timestamp: new Date().toISOString(),
    });

    // Check emergency triggers immediately
    const lowerMsg = message.toLowerCase();
    const isUrgentTrigger =
      lowerMsg.includes('chest pain') ||
      lowerMsg.includes('सीने में दर्द') ||
      lowerMsg.includes('छातीत दुखणे') ||
      lowerMsg.includes('heart attack') ||
      lowerMsg.includes('unconscious') ||
      lowerMsg.includes('cannot breathe') ||
      lowerMsg.includes('saans lene me dikkat');

    if (isUrgentTrigger) {
      session.isComplete = true;
      session.isEmergency = true;
      session.guidanceResult = {
        ...demoData.emergencyGuidance,
        conversationId: sessionId,
      };

      const emergencyAlertMsg =
        session.language === 'hi'
          ? '🚨 आपातकालीन चेतावनी: आपके लक्षण गंभीर लग रहे हैं। कृपया तुरंत 112 पर कॉल करें या नजदीकी आपातकालीन अस्पताल जाएं।'
          : session.language === 'mr'
          ? '🚨 आणीबाणी इशारा: तुमची लक्षणे गंभीर असू शकतात. कृपया त्वरित 112 वर संपर्क साधा किंवा जवळच्या रुग्णालयात जा.'
          : '🚨 CRITICAL MEDICAL ALERT: Your symptoms may require immediate medical attention. Please dial 112 or visit the nearest emergency room immediately.';

      session.history.push({
        sender: 'assistant',
        text: emergencyAlertMsg,
        timestamp: new Date().toISOString(),
      });

      return {
        session,
        isEmergency: true,
        suggestions: ['Call 112 Now', 'Nearest Emergency Hospitals', 'Ambulance Support'],
        guidanceResult: session.guidanceResult,
        aiProvider: 'demo',
      };
    }

    // If Gemini API is available and demo mode is not forced, try Gemini Live/Flash
    if (ai && !useDemoMode) {
      try {
        const conversationText = session.history
          .map((h) => `${h.sender.toUpperCase()}: ${h.text}`)
          .join('\n');

        const prompt = `Language requested: ${session.language}\nConversation History so far:\n${conversationText}\n\nProvide the next response strictly as the specified JSON object.`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            responseMimeType: 'application/json',
          },
        });

        const rawText = response.text || '{}';
        const parsed = JSON.parse(rawText);

        if (parsed.message) {
          session.history.push({
            sender: 'assistant',
            text: parsed.message,
            timestamp: new Date().toISOString(),
          });

          if (parsed.guidanceResult) {
            session.isComplete = true;
            session.guidanceResult = parsed.guidanceResult;
          }

          if (parsed.isEmergency) {
            session.isEmergency = true;
          }

          return {
            session,
            nextQuestion: parsed.isFollowUp ? parsed.message : undefined,
            suggestions: parsed.quickSuggestions || ['Consult Doctor', 'Find Nearby Clinic'],
            guidanceResult: parsed.guidanceResult,
            isEmergency: parsed.isEmergency || false,
            aiProvider: 'gemini',
          };
        }
      } catch (geminiError) {
        console.warn('Gemini generateContent error, gracefully using demo flow:', geminiError);
      }
    }

    // Controlled Hackathon Demo Mode Flow
    const nextStep = session.step + 1;
    session.step = nextStep;

    if (nextStep < demoData.dialogue.length) {
      const dialogueItem = demoData.dialogue[nextStep];
      let qText = dialogueItem.aiQuestion;
      if (session.language === 'hi' && dialogueItem.aiQuestionHi) {
        qText = dialogueItem.aiQuestionHi;
      } else if (session.language === 'mr' && dialogueItem.aiQuestionMr) {
        qText = dialogueItem.aiQuestionMr;
      }

      session.history.push({
        sender: 'assistant',
        text: qText,
        timestamp: new Date().toISOString(),
      });

      return {
        session,
        nextQuestion: qText,
        suggestions: dialogueItem.quickSuggestions,
        isEmergency: false,
        aiProvider: 'demo',
      };
    } else {
      session.isComplete = true;
      session.guidanceResult = {
        ...demoData.standardGuidance,
        conversationId: sessionId,
        language: session.language,
      };

      const finalMsg =
        session.language === 'hi'
          ? 'आपके द्वारा दी गई जानकारी के आधार पर हमने आपका मार्गदर्शन तैयार किया है। कृपया नीचे दिए गए परिणाम देखें।'
          : session.language === 'mr'
          ? 'तुम्ही दिलेल्या माहितीच्या आधारे आम्ही मार्गदर्शन तयार केले आहे. कृपया खालील परिणाम पहा.'
          : 'Based on the information provided, here is your care guidance and recommended next step.';

      session.history.push({
        sender: 'assistant',
        text: finalMsg,
        timestamp: new Date().toISOString(),
      });

      return {
        session,
        guidanceResult: session.guidanceResult,
        isEmergency: false,
        aiProvider: 'demo',
      };
    }
  }

  getSession(sessionId: string): AISessionState | undefined {
    return sessions.get(sessionId);
  }

  clearSession(sessionId: string): void {
    sessions.delete(sessionId);
  }
}

export const aiService = new AIService();
